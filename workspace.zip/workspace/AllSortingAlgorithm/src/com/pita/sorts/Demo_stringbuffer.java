package com.pita.sorts;

public class Demo_stringbuffer {
    final static StringBuffer s=new StringBuffer("abc");
	public static void main(String[] args) {
		
	}

}
