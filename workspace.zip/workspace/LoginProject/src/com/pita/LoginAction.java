package com.pita;

public class LoginAction extends Action{

}
