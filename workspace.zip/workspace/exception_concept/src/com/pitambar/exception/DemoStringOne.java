package com.pitambar.exception;

public class DemoStringOne {
	public void sit(){
		String a=new String("prabhat");
		
		System.out.println(a);
		
		//System.out.println(s);
	}
	public void st(){
		String c=new String("prabhat");
		
		System.out.println(c);
		
		//System.out.println(s);
	}

}
