
public interface Test {
	public void methodTest();

}
