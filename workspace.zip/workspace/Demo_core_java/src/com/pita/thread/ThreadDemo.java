package com.pita.thread;

public class ThreadDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
